XPD=`pwd`

export basepath=$XPD/lib
source /share/sl6/set_asc.sh
export CLASSPATH=.:${basepath}/freehep-mcfio-2.0.1.jar:${basepath}/lcio-2.4.4-SNAPSHOT-bin.jar:${basepath}/freehep-xdr-2.0.3.jar:${basepath}/browser_promc.jar
