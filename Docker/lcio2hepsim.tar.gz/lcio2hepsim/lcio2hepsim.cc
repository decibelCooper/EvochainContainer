// Adding extra block MCinfo to the LCIO data format.
// It also remove simulated calorimeter hits (event sliming)
// Author: Sergei Chekanov (ANL) 
// March 2017. Version 1.1

#include <cstdlib>
#include <string>
#include <cassert>
#include <iostream>

#include "EVENT/LCCollection.h"
#include "EVENT/SimCalorimeterHit.h"
#include "EVENT/CalorimeterHit.h"
#include "EVENT/MCParticle.h"
#include "EVENT/LCFloatVec.h"
#include "EVENT/LCIntVec.h"
#include "EVENT/Track.h"
#include "EVENT/Cluster.h"
#include "EVENT/ReconstructedParticle.h"
#include "EVENT/Vertex.h"
#include "EVENT/LCGenericObject.h"
#include "EVENT/LCRelation.h"
#include "lcio.h"
#include <stdio.h>
#include "IO/LCReader.h"
#include "IMPL/LCTOOLS.h"
#include "EVENT/LCEvent.h"
#include "EVENT/LCRunHeader.h"
#include "EVENT/CalorimeterHit.h"
#include "EVENT/LCIO.h"
#include "IMPL/LCEventImpl.h"
#include "IMPL/LCRunHeaderImpl.h"
#include "IOIMPL/LCFactory.h"
#include "EVENT/MCParticle.h"
#include "IMPL/LCEventImpl.h"
#include "UTIL/LCTOOLS.h"
#include "UTIL/Operators.h"
#include "UTIL/LCIterator.h"
#include "IMPL/LCCollectionVec.h"
#include "IMPL/MCParticleImpl.h"
#include "EVENT/MCParticle.h"
#include "EVENT/ReconstructedParticle.h"
#include "EVENT/Track.h"
#include "EVENT/Cluster.h"
#include "EVENT/CalorimeterHit.h"

using namespace std;
using namespace lcio ;


int main(int argc, char** argv) {

  // Look for a help argument
  for (int i = 1; i < argc; ++i) {
    const string arg = argv[i];
    if (arg == "--help" || arg == "-h") {
      cout << argv[0] << ": a LCIO modification tool" << endl;
      cout << "Usage: " << argv[0] << "[<input LCIO file> <input LCIO with MCtruth> <output LCIO file>]" << endl;
      cout << "This program adds MCinfo to the standard LCIO record" << endl;
      exit(0);
    }
  }

  // Choose input and output files from the command line
  string infile1("-"), infile2("-"), outfile("-");
  if (argc == 4) {
    infile1 = argv[1];
    infile2 = argv[2];
    outfile = argv[3];
  } else if (argc != 4) {
    cerr << "Usage: " << argv[0] << "[<input LCIO file> <input LCIO with MCtruth> <output LCIO file>]" << endl;
    exit(1);
  }

  cout << "Input PANDORA=" << infile1 << endl;
  cout << "Input TRUTH  =" << infile2 << endl;
  cout << "Output LCIO  =" << outfile << endl;


  // IO::LCReader* lcReader = IOIMPL::LCFactory::getInstance()->createLCReader() ;
  LCReader* lcReader = LCFactory::getInstance()->createLCReader() ;
  lcReader->open( infile1.c_str() ) ;

  LCReader* lcReaderTrue = LCFactory::getInstance()->createLCReader( IO::LCReader::directAccess ) ;
  lcReaderTrue->open( infile2.c_str() ) ;

  LCWriter* lcWriter = LCFactory::getInstance()->createLCWriter() ;
  lcWriter->open( outfile.c_str() ) ;

    int nEvents=0;
    string mcpName;


    // collect truth info
/*
    LCRunHeader* rHdr;
    while( (rHdr = lcReader->readNextRunHeader()) != 0 ) {
    LCRunHeader* rHdr = lcReader->readNextRunHeader() ;
    lcWriter->writeRunHeader( rHdr ) ;
    }
*/


 //LCRunHeader* rHdr = lcReader->readNextRunHeader() ;
 // create new run header

/*
    LCRunHeaderImpl*   runHdr = new LCRunHeaderImpl();
    runHdr->setRunNumber( 0 ) ;
    runHdr->setDetectorName( "xxx" ) ;
    runHdr->setDescription( "xxx" ) ;
     // Write SLIC version into run header.
     //m_runHdr->parameters().setValue("SLIC_VERSION", PackageInfo::getVersion());
     // Write Geant4 version into run header.
     //m_runHdr->parameters().setValue("GEANT4_VERSION", Geant4VersionInfo::getVersion());
     lcWriter->writeRunHeader( runHdr  ) ;
*/




// run over headers
/*
        LCRunHeader *runHdr ;
        try{
                // loop over all run headers
                while( ( runHdr = lcReader->readNextRunHeader() ) != 0 ){
                cout << "  Run : " << runHdr->getRunNumber()
                << " - "      << runHdr->getDetectorName()
                << ":  "      << runHdr->getDescription()  << endl ;
                }

        }catch(IOException& e){
                cout << " io error when reading run data : " << e.what() << endl ;
        }
        cout << endl ;
        lcReader->close() ;
*/



    //lcReader->open( infile1 ) ;
    //cout << " reopened " << infile1 << " for reading " << endl ;


    LCEvent*  evt;
    mcpName="MCParticle";

/*
    LCEvent* evtTrue  = lcReaderTrue->readEvent (1, 0, LCIO::READ_ONLY);
    const LCParameters& paramsT=evtTrue->getParameters();
    cout << "   0 truth event " << endl;
    IMPL::LCCollectionVec* col2 = (IMPL::LCCollectionVec*) evtTrue->getCollection( mcpName  ) ;
    int nMCP2 = col2->getNumberOfElements() ;
    for(int i=0 ; i<nMCP2 ; ++i){
      EVENT::MCParticle* mcp =  (EVENT::MCParticle*) col2->getElementAt(i) ;
      px = mcp->getMomentum()[0];
      py = mcp->getMomentum()[1];
      pz = mcp->getMomentum()[2];
       if (i<10) cout << i << " " << mcp->getPDG() << " " << px << " " << py << " " <<  pz << endl;
    }
*/


   
      while( (evt = lcReader->readNextEvent(  LCIO::READ_ONLY )) != 0 ) {

      // if (nEvents==0) UTIL::LCTOOLS::dumpEvent( evt ) ;      
      if (nEvents%10==0)
          cout <<  " # Events=" << nEvents << endl;
      if (nEvents==0) cout << "  Run : " << evt->getRunNumber()
                << " - "      << evt->getDetectorName() <<  endl ;

    int run= evt->getRunNumber()+1;
//  note we set +1, since 0 truth event is a dummy (how it is filled by ProMC)
    int event=evt->getEventNumber()+1;
//  cout << "\nCurrent Event=" << event << endl;
// get truth info
    LCEvent* evtTrue  = lcReaderTrue->readEvent (run, event, LCIO::READ_ONLY);
    if (evtTrue ==0) {cout << "Error: event = " << event << " does not identify truth-level file correctly. Exit! " << endl; exit(0); } 
    const LCParameters& paramsT=evtTrue->getParameters();



// checks for consistancy of reco and truth events  
/*
    double px,py,pz;
    cout << "\nEvent=" << nEvents << endl;
    cout << "   reco event " << endl;
    IMPL::LCCollectionVec* col1 = (IMPL::LCCollectionVec*) evt->getCollection( mcpName  ) ;
    int nMCP1 = col1->getNumberOfElements() ;
    for(int i=0 ; i<nMCP1 ; ++i){
      EVENT::MCParticle* mcp =  (EVENT::MCParticle*) col1->getElementAt(i) ;
      px = mcp->getMomentum()[0];
      py = mcp->getMomentum()[1];
      pz = mcp->getMomentum()[2];
      if (i<10) cout << i << " " << mcp->getPDG() << " " << px << " " << py << " " <<  pz << endl;
    }

    cout << "   truth event " << endl;
    IMPL::LCCollectionVec* col2 = (IMPL::LCCollectionVec*) evtTrue->getCollection( mcpName  ) ;
    int nMCP2 = col2->getNumberOfElements() ;
    for(int i=0 ; i<nMCP2 ; ++i){
      EVENT::MCParticle* mcp =  (EVENT::MCParticle*) col2->getElementAt(i) ;
      px = mcp->getMomentum()[0];
      py = mcp->getMomentum()[1];
      pz = mcp->getMomentum()[2];
       if (i<10) cout << i << " " << mcp->getPDG() << " " << px << " " << py << " " <<  pz << endl;
    }
*/




   // event out
   IMPL::LCEventImpl*  evt_out = new IMPL::LCEventImpl() ;     // create the event

   /*
   LCRunHeaderImpl* runHdr = new LCRunHeaderImpl ; 
   runHdr->setRunNumber( evt->getRunNumber() ) ;
   runHdr->setDetectorName( evt->getDetectorName() ) ;
   vt->setEventNumber( i ) ;  
   lcWrt->writeRunHeader( runHdr ) ;
   delete runHdr ;  
   */


    evt_out->setRunNumber(run);
    evt_out->setEventNumber(event);
    evt_out->setDetectorName(evt->getDetectorName());
    evt_out->setTimeStamp(evt->getTimeStamp()) ;
    evt_out->setWeight(evt->getWeight());
    //evt_out->parameters().setValue("SLIC_VERSION", "5.0");
    // Write Geant4 version into event header.
    //evt_out->parameters().setValue("GEANT4_VERSION", "10.2");





 // now move names and parameters from truth-level file
           if (nEvents==0) cout << "-> Adding parameter from truth-level file:" << endl;
           StringVec intKeysT ;
           int nIntParametersT = paramsT.getIntKeys( intKeysT ).size() ;
           for(int i=0; i< nIntParametersT ; i++ ){
           IntVec intVecT ;
           paramsT.getIntVals(  intKeysT[i], intVecT ) ;
           int nInt  = intVecT.size()  ;
           if (nEvents==0) cout << " parameter " << intKeysT[i] << " [int]: " ;
           if( nInt == 0 ){
           if (nEvents==0) cout << " [empty] " << std::endl ;
           }
           for(int j=0; j< nInt ; j++ ){
           if (nEvents==0) cout << intVecT[j] << ", " ;
           evt_out->parameters().setValue(intKeysT[i], intVecT[j]);
           }
           if (nEvents==0) cout << endl;
           }
           StringVec floatKeysT ;
           int nFloatParametersT = paramsT.getFloatKeys( floatKeysT ).size() ;
           for(int i=0; i< nFloatParametersT ; i++ ){
           FloatVec floatVecT ;
           paramsT.getFloatVals(  floatKeysT[i], floatVecT ) ;
           int nFloat  = floatVecT.size()  ;
           if (nEvents==0) cout << " parameter " << floatKeysT[i] << " [float]: " ;
           if( nFloat == 0 ){
           if (nEvents==0) cout << " [empty] " << std::endl ;
           }
           for(int j=0; j< nFloat ; j++ ){
           if (nEvents==0) cout << floatVecT[j] << ", " ;
           evt_out->parameters().setValue(floatKeysT[i], floatVecT[j]);
           }
           if (nEvents==0) cout << endl ;
           }
           StringVec stringKeysT ;
           int nStringParametersT = paramsT.getStringKeys( stringKeysT ).size() ;
           for(int i=0; i< nStringParametersT ; i++ ){
           StringVec stringVecT ;
           paramsT.getStringVals(  stringKeysT[i], stringVecT ) ;
           int nString  = stringVecT.size()  ;
           if (nEvents==0) cout << " parameter " << stringKeysT[i] << " [string]: " ;
           if( nString == 0 ){
           if (nEvents==0) cout << " [empty] " << std::endl ;
           }
           for(int j=0; j< nString ; j++ ){
           if (nEvents==0) cout << stringVecT[j] << ", " ;
           evt_out->parameters().setValue(stringKeysT[i], stringVecT[j]);
           }
           if (nEvents==0) cout << endl ;
           }



           if (nEvents==0) cout << "-> Adding parameter from reco-level file:" << endl;
          // copy names and parameters
           const LCParameters& params=evt->getParameters();
           StringVec intKeys ;
           int nIntParameters = params.getIntKeys( intKeys ).size() ;
           for(int i=0; i< nIntParameters ; i++ ){
           IntVec intVec ;
           params.getIntVals(  intKeys[i], intVec ) ;
           int nInt  = intVec.size()  ;
           if (nEvents==0) cout << " parameter " << intKeys[i] << " [int]: " ;

           if( nInt == 0 ){
           if (nEvents==0) cout << " [empty] " << std::endl ;
           }
           for(int j=0; j< nInt ; j++ ){
           if (nEvents==0) cout << intVec[j] << ", " ;
           evt_out->parameters().setValue(intKeys[i], intVec[j]);
           }
           if (nEvents==0) cout << endl ;
           }
           StringVec floatKeys ;
           int nFloatParameters = params.getFloatKeys( floatKeys ).size() ;
           for(int i=0; i< nFloatParameters ; i++ ){
           FloatVec floatVec ;
           params.getFloatVals(  floatKeys[i], floatVec ) ;
           int nFloat  = floatVec.size()  ;
           if (nEvents==0) cout << " parameter " << floatKeys[i] << " [float]: " ;
           if( nFloat == 0 ){
           if (nEvents==0) cout << " [empty] " << std::endl ;
           }
           for(int j=0; j< nFloat ; j++ ){
           if (nEvents==0) cout << floatVec[j] << ", " ;
           evt_out->parameters().setValue(floatKeys[i], floatVec[j]);
           }
           if (nEvents==0) cout << endl ;
           }
           StringVec stringKeys ;
           int nStringParameters = params.getStringKeys( stringKeys ).size() ;
           for(int i=0; i< nStringParameters ; i++ ){
           StringVec stringVec ;
           params.getStringVals(  stringKeys[i], stringVec ) ;
           int nString  = stringVec.size()  ;
           if (nEvents==0) cout << " parameter " << stringKeys[i] << " [string]: " ;
           if( nString == 0 ){
           if (nEvents==0) cout << " [empty] " << std::endl ;
           }
           for(int j=0; j< nString ; j++ ){
           if (nEvents==0) cout << stringVec[j] << ", " ;
           evt_out->parameters().setValue(stringKeys[i], stringVec[j]);
           }
           if (nEvents==0) cout << endl ;
           }



    evt_out->parameters().setValue ( "HepSim", "1.1" );
    evt_out->parameters().setValue ( "ProcessID", "-1" );
    evt_out->parameters().setValue ( "_idrup", "-1" ); // IDRUP is used to flag the event type 
    //evt_out->parameters().setValue("SLIC_VERSION", "5.0");
    // Write Geant4 version into event header.
    //evt_out->parameters().setValue("GEANT4_VERSION", "10.2");



   LCRunHeaderImpl* runHdr = new LCRunHeaderImpl ; 
   runHdr->setRunNumber( evt->getRunNumber() ) ;
   runHdr->setDetectorName( evt->getDetectorName() ) ;
   runHdr->setDescription("HepSim record");
   runHdr->parameters().setValue( "HepSim data layout" , "1.0" ) ;
   runHdr->parameters().setValue("SLIC_VERSION", "5.0");
   // Write Geant4 version into run header.
   runHdr->parameters().setValue("GEANT4_VERSION", "10.2");
   lcWriter->writeRunHeader( runHdr ) ;
   delete runHdr;
 

    //mcpName="MCInfo";
    //IMPL::LCCollectionVec* MCInfo = (IMPL::LCCollectionVec*) evtTrue->getCollection( mcpName  ) ;
    //evt_out->addCollection(MCInfo,mcpName);

    // optional
    //mcpName="MCParameters";
    //IMPL::LCCollectionVec* MCParameters = (IMPL::LCCollectionVec*) evtTrue->getCollection( mcpName  ) ;
    //if (MCParameters !=0) evt_out->addCollection(MCInfo,mcpName);


   // get collection names from MC truth, and  
    const std::vector< std::string >* strVec_truth = evtTrue->getCollectionNames() ;
    for( std::vector< std::string >::const_iterator name = strVec_truth->begin() ; name != strVec_truth->end() ; name++){
          string xname(*name);
          if (!xname.compare("MCParticle")) continue; // no need to add, since it will be copied from the original 
          if (nEvents==0) cout << " -> collection to be added: " << xname << endl;
          LCCollection* col_truth = evtTrue->getCollection( *name ) ;
          evt_out->addCollection(col_truth,xname);
        }


// dump all
    const std::vector< std::string >* strVec = evt->getCollectionNames() ;
    for( std::vector< std::string >::const_iterator name = strVec->begin() ; name != strVec->end() ; name++){
        if (nEvents==0) {
            //cout.width(30); cout << left << *name;
            //cout.width(25); cout << left << evt->getCollection( *name )->getTypeName();
            //cout.width(9); cout << right << evt->getCollection( *name )->getNumberOfElements();
            //cout << endl;
          }

          // skip simulated higs
          string xname(*name);
          if (!xname.compare("EcalBarrelHits")) continue;
          if (!xname.compare("EcalEndcapHits")) continue;
          if (!xname.compare("HcalBarrelHits")) continue;
          if (!xname.compare("HcalEndcapHits")) continue;

          LCCollection* col = evt->getCollection( *name ) ;
          evt_out->addCollection(col,xname);
            //cout << "---------------------------------------------------------------------------" << endl;
        }


/*
    mcpName="MCParticle";
    IMPL::LCCollectionVec* MCParticle = (IMPL::LCCollectionVec*) evt->getCollection( mcpName  ) ;
    evt_out->addCollection(MCParticle,mcpName);


    mcpName="PandoraPFOCollection";
    IMPL::LCCollectionVec* PandoraPFOCollection = (IMPL::LCCollectionVec*) evt->getCollection( mcpName  ) ;
    evt_out->addCollection(PandoraPFOCollection,mcpName);

    mcpName="Tracks";
    IMPL::LCCollectionVec* Tracks = (IMPL::LCCollectionVec*) evt->getCollection( mcpName  ) ;
    evt_out->addCollection(Tracks,mcpName);


    mcpName="ReconClusters";
    IMPL::LCCollectionVec* ReconClusters = (IMPL::LCCollectionVec*) evt->getCollection( mcpName  ) ;
    evt_out->addCollection(ReconClusters,mcpName);
*/


/*   
    mcpName="HAD_BARREL";
    IMPL::LCCollectionVec* HAD_BARREL = (IMPL::LCCollectionVec*) evt->getCollection( mcpName  ) ;
    evt_out->addCollection(ReconClusters,mcpName);
*/


    lcWriter->writeEvent( evt_out ) ;              // write the event to the file
    nEvents ++ ;
   }

  lcReaderTrue->close();
  lcReader->close() ;
  lcWriter->close();

  cout << "Output LCIO  =" << outfile << endl;

  return EXIT_SUCCESS;
}
